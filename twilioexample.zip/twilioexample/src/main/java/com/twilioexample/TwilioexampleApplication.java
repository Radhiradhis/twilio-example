package com.twilioexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TwilioexampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(TwilioexampleApplication.class, args);
	}

}
